#ifndef __ELAPSED_TIMER_HPP__
#define __ELAPSED_TIMER_HPP__

#ifndef __WINDOWS_MM__
  #include <sys/time.h>
#else
  #include <windows.h>
#endif

#include <cstddef> // NULL

class ElapsedTimer
{
public:
  ElapsedTimer()
  : startPoint_(0)
  {
  #ifdef __WINDOWS_MM__
    QueryPerformanceCounter(&qpcount);
    QueryPerformanceFrequency(&qpfreq);
  #endif
  }

  double getElapsedTimeInSec()
  {
    return this->getCurrentTimeInSec() - startPoint_;
  }

  void start()
  {
    startPoint_ = this->getCurrentTimeInSec();
  }

  double getCurrentTimeInSec()
  {
  #ifndef __WINDOWS_MM__
    gettimeofday(&val, NULL);
    return val.tv_sec + (double)(val.tv_usec / 1000000.0);
  #else
    QueryPerformanceCounter(&qpcount);
    return (double)(qpcount.QuadPart) / (double)(qpfreq.QuadPart);
  #endif
  }

private:

  double startPoint_;

#ifndef __WINDOWS_MM__
  timeval val;
#else
  LARGE_INTEGER qpfreq;
  LARGE_INTEGER qpcount;
#endif

};


#endif
