#ifndef EDITWINDOW_H
#define EDITWINDOW_H

#include <QMainWindow>
#include <QAction>
#include <QToolBar>
#include <QPushButton>
#include <QComboBox>
#include <QLineEdit>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QKeyEvent>

#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<fstream>
#include<vector>
#include<cassert>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>

#include "ScorePerfmMatch_v170104.hpp"
#include "Fmt3x_v170104.hpp"
#include "Midi_v170101.hpp"
#include "PianoRoll_v170101.hpp"
#include "MidiPlayer.hpp"
#include "RtMidiController.hpp"
#include "ScrollBar.h"

using namespace std;

class EditWindow : public QMainWindow{
	Q_OBJECT

public:
	EditWindow(QWidget *parent = 0);
	~EditWindow();
	QToolBar *fileToolBar;
	QToolBar *editToolBar;
	QToolBar *portToolBar;
	QToolBar *startbuttonToolBar;
	QToolBar *channelToolBar;
	QAction *openScoreAct;
	QAction *openMatchAct;
	QAction *reloadAct;
	QAction *saveAct;
	QAction *printAct;
	QAction *enlargeTimeAxis;
	QAction *reduceTimeAxis;
	QAction *letterSizeSwitchAct;
	QAction *switchSegmentPos;


	QGraphicsScene *m_scene;
	QGraphicsView *m_view;

	QPushButton *channelSwitchButton;
	QPushButton *startButton;
	QPushButton *resumeButton;
	QLineEdit   *startTimeLineEdit;
	QComboBox   *portCombo;

	void AddItem(QGraphicsItem *item);
	void RemoveItem(int itemNum);
	void PrintView(QString file);
	void SaveFile(string filename);
	void OpenMatchFile();
	void OpenScoreFile();
	void ReloadFile();
	void drawScorePerfmMatch();
	string curScoreFile;
	string curMatchFile;

	void Divide();

	double pxPerSec;
	int secPerLine;
	double staffLineSpace;
	double endtime;
	int numOfLines;
	double xoffset;
	double yoffset;
	double width;
	double widthLast;
	double heightPerLine;
	double height;
	double unitStrokeWidth;
	double clefFontSize;
	double accFontSize;
	double textFontSize;
	double YOFF_clef;
	double YOFF_time;
	double YOFF_acc;
	double yoffset2;
	double graceNoteDuration;//0.07

	void addLedgerLine(int ditchHeight,double onPos_,double yoffset_);
	void drawStaffLines(double yoffset_);
	void drawTimeLines(double yoffset_);
	void drawNote(int onLine_,int offLine_, double onPos_, double offPos_, int ditchHeight_,int acc_,int onvel_,double yoffset_,int errorInd=0);
	void DrawFmt1ID(int,double,int,string,int);

	void Stress(int perfmID);
	void Unstress();

public slots:
	void OpenMatch();
	void OpenScore();
	void Reload();
	void Save();
	void Print();
	void MySelected();
	void LargerTimeAxis();
	void SmallerTimeAxis();
	void LetterSizeSwitchClicked();
	void SegmentPosChanged();

	void on_ChannelSwitchClicked();
	void on_StartClicked();
	void on_ResumeClicked();
	void on_PortComboIndexChanged(int);
	void on_PlayIsFinished();

protected:
	void keyPressEvent(QKeyEvent *e){
		switch (e->key()){
			case Qt::Key_Greater:
				Pressed_Greater();
				break;
			case Qt::Key_Less:
				Pressed_Less();
				break;
			case Qt::Key_Tab:
				Pressed_Tab();
				break;
			case Qt::Key_Backtab:
				Pressed_ShiftTab();
				break;
			case Qt::Key_S:
				if(e->modifiers()==Qt::ControlModifier){
					Pressed_Save();
				}//endif
				break;
			case Qt::Key_P:
				if(e->modifiers()==Qt::ControlModifier){
					Pressed_Print();
				}//endif
				break;
			case Qt::Key_D:
				if(e->modifiers()==Qt::ControlModifier){
					Pressed_Divide();
				}//endif
				break;
			default:
				QWidget::keyPressEvent(e);
		}//endswitch
	};

private:
	void CreateActions();
	void CreateToolBars();

	void Pressed_Greater();
	void Pressed_Less();
	void Pressed_Tab();
	void Pressed_ShiftTab();
	void Pressed_Save();
	void Pressed_Print();
	void Pressed_Divide();

	void startMidi(double);
	void setScoreMidiToPlayer();
	void setPerfmMidiToPlayer();
	void enableStartButton();
	void startScrollBar(int);
	void stopScrollBar();

	Fmt3x score;
	ScorePerfmMatch scorePerfmMatch;
	Midi scoreMidi;
	Midi perfmMidi;

	vector<int> itemID;//itemID for each drawn event
	int numItems;//
	vector<vector<int> > perfmItemID;//0: fmt1Id, 1: square, 2: round square, 3: matching line, 4: line tip (perform), 5: line tip (score)
	string curSaveFilename;
	QString curPrintFilename;
	vector<vector<double> > matchingLinePos;//x1,y1,x2,y2
	vector<int> stressedItemNums;

	bool isBigLetter;
	int segmentOffset;
	int segmentSize;

	bool isPlaying;
	bool isChannelScore;
	MidiPlayer player;

	ScrollBar *scrollBar;

};//end class EditWindow

#endif // EDITWINDOW_H
