#include "editwindow.h"
#include "qdebug.h"
#include "qfiledialog.h"
#ifdef _WIN32
	#include <windows.h>
	inline void usleep(int microseconds) { Sleep(1000 * (DWORD)microseconds); }
#else
	#include "unistd.h"
#endif
#include <QPrinter>
#include <QPrintDialog>
#include <QPainter>
#include <QtGui>
#include <QTransform>
#include <QComboBox>
#include <QPushButton>

using namespace std;

inline QColor accToColor(int acc){
//  if(acc==0){return "orange";
  if(acc==0){return QColor(255,128,0);
  }else if(acc==1){return QColor(Qt::black);
  }else if(acc==2){return QColor(Qt::red);
  }else if(acc==-1){return QColor(Qt::darkGreen);
  }else if(acc==-2){return QColor(Qt::cyan);
  }else{return QColor(Qt::black);
  }//endif
};
inline string accToSymbol(int acc){
//  if(acc==0){return "n";
  if(acc==0){return "";
  }else if(acc==1){return "#";
  }else if(acc==2){return "‹";//"&#x2039;"
  }else if(acc==-1){return "b";
  }else if(acc==-2){return "∫";//"&#x222B;"
  }else{return "";
  }//endif
};
inline QColor lineColor(int i){
//  if(acc==0){return "orange";
  if(i<0){return QColor(Qt::black);}
  i=i%9;
  if(i==0){return QColor(Qt::blue);
  }else if(i==1){return QColor(165,42,42);//brown
  }else if(i==2){return QColor(0,128,0);//green
  }else if(i==3){return QColor(150,100,255);//lightpurple
  }else if(i==4){return QColor(255,127,80);//coral
  }else if(i==5){return QColor(173,255,47);//greenyellow
  }else if(i==6){return QColor(80,80,80);//slategrey
  }else if(i==7){return QColor(255,0,255);//magenta
  }else if(i==8){return QColor(0,255,255);//aqua
  }else{return QColor(Qt::black);
  }//endif
};

inline string Simplifyfmt1ID(string fmt1ID){
	if(fmt1ID[0]=='*'){return "*";}
	if(fmt1ID[0]=='&'){return "&";}
	if(fmt1ID.substr(0,fmt1ID.find('-'))=="P1"){
		return fmt1ID.substr(fmt1ID.find('-')+1);
	}else{
		return fmt1ID;
	}//endif
}//

inline string Completefmt1ID(string str){
	if(str[0]=='*'){return "*";}
	if(str[0]=='&'){return "&";}
	if(str[0]!='P'){
		return "P1-"+str;
	}else{
		return str;
	}//endif
}//

EditWindow::EditWindow(QWidget *parent) : QMainWindow(parent){

	setBaseSize(2800,1400);
	m_scene=new QGraphicsScene;
	m_view=new QGraphicsView;
	m_scene->setSceneRect(0,0,2800,1400);
	m_view->setScene(m_scene);
	m_view->setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);
	m_view->scale(1/2.0736,1/2.0736);
	setCentralWidget(m_view);
	m_view->centerOn(0,0);

	CreateActions();
	CreateToolBars();

	numItems=0;
	curSaveFilename="";
	curPrintFilename="";
	curScoreFile="";
	curMatchFile="";
	pxPerSec=400;//def=400
	secPerLine=9999;//def=9999
	staffLineSpace=20;//def=20

	graceNoteDuration=0.07;

	connect(m_scene, SIGNAL(selectionChanged()), this, SLOT(MySelected()));

}//end EditWindow

EditWindow::~EditWindow(){
}//end ~EditWindow

void EditWindow::AddItem(QGraphicsItem *item){
	m_scene->addItem(item);
	numItems+=1;
}//end AddItem
void EditWindow::RemoveItem(int itemNum){
	QList<QGraphicsItem *> items=m_scene->items();
	m_scene->removeItem(items[numItems-1-itemNum]);
	numItems-=1;
}//end RemoveItem


void EditWindow::drawScorePerfmMatch(){
  m_scene->clear();
  itemID.clear();
  numItems=0;
  perfmItemID.clear();
  matchingLinePos.clear();
  stressedItemNums.clear();

  if(scorePerfmMatch.evts.size()==0){
    QGraphicsTextItem *itemText = new QGraphicsTextItem("No score-performance matching event");
    itemText->setFont(QFont("Times",20));
    itemText->setPos(200,200);
    AddItem(itemText);
    return;
  }//endif
  perfmItemID.resize(scorePerfmMatch.evts.size());
  matchingLinePos.resize(scorePerfmMatch.evts.size());
  for(int i=0;i<perfmItemID.size();i+=1){
    perfmItemID[i].resize(6);
    matchingLinePos[i].resize(8);
  }//endfor i

  double secPerTick=0.01;//def=0.03
  endtime=0;
  for(int n=scorePerfmMatch.evts.size()-1;n>=0;n-=1){
    if(scorePerfmMatch.evts[n].ontime>endtime){endtime=scorePerfmMatch.evts[n].ontime;}
    if(scorePerfmMatch.evts[n].offtime>endtime){endtime=scorePerfmMatch.evts[n].offtime;}
  }//endfor n
  endtime=int(endtime)+1;

  numOfLines=int(endtime/secPerLine)+1;
  xoffset=2*staffLineSpace;
  yoffset=11*staffLineSpace;
  width=int(pxPerSec*secPerLine)+4*xoffset;
  widthLast=int(pxPerSec*(endtime-int(endtime/secPerLine)*secPerLine))+4*xoffset;
  heightPerLine=3*yoffset+2*10*staffLineSpace;
  height=numOfLines*heightPerLine;
  unitStrokeWidth=staffLineSpace/20.;
#ifdef __WINDOWS_MM__
  // Windows
  clefFontSize=3.1*staffLineSpace;
  accFontSize=2*staffLineSpace;
  textFontSize=staffLineSpace;
  YOFF_clef=-2.55*staffLineSpace;
  YOFF_time=0*staffLineSpace;
  YOFF_acc=-1.75*staffLineSpace;
#else
  // Not Windows
  clefFontSize=4*staffLineSpace;
  accFontSize=2*staffLineSpace;
  textFontSize=staffLineSpace;
  YOFF_clef=-1.3*staffLineSpace;
  YOFF_time=0*staffLineSpace;
  YOFF_acc=-0.75*staffLineSpace;
#endif

  yoffset2=yoffset*2+10*staffLineSpace;

  if(numOfLines==1){width=widthLast;}
  m_scene->setSceneRect(0,0,width+4*xoffset,height);

  drawStaffLines(yoffset);
  drawStaffLines(yoffset2);
  drawTimeLines(yoffset);
  drawTimeLines(yoffset2);

////// Draw score & match file names
{
	string shortFileName=curScoreFile;
	shortFileName=shortFileName.substr(shortFileName.rfind("/")+1,shortFileName.size());
	QGraphicsTextItem *item = new QGraphicsTextItem(QString::fromStdString(shortFileName));
	item->setFont(QFont("Times",textFontSize));
	item->setPos(xoffset,yoffset-3*staffLineSpace);
	item->setDefaultTextColor(QColor(255,100,100));
	AddItem(item);
}{
	string shortFileName=curMatchFile;
	shortFileName=shortFileName.substr(shortFileName.rfind("/")+1,shortFileName.size());
	QGraphicsTextItem *item = new QGraphicsTextItem(QString::fromStdString(shortFileName));
	item->setFont(QFont("Times",textFontSize));
	item->setPos(xoffset,yoffset2-3*staffLineSpace);
	item->setDefaultTextColor(QColor(255,100,100));
	AddItem(item);
}

	vector<int> perfmSegmentIds;//Segmentation of performance according to skip indication
	perfmSegmentIds.push_back(0);
	////////////////// Draw performed notes
	for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
		if(n>0 && scorePerfmMatch.evts[n].skipInd!="-"){perfmSegmentIds.push_back(n);}//endif
		if(n>0 && n%segmentSize==segmentOffset){
			for(int m=n;m<n+segmentSize/2&&m<scorePerfmMatch.evts.size();m+=1){
				if(scorePerfmMatch.evts[m].errorInd>1){continue;}
				if(scorePerfmMatch.evts[m].stime!=scorePerfmMatch.evts[m-1].stime){
					perfmSegmentIds.push_back(m);
					break;
				}//endif
			}//endfor m
		}//endif
		ScorePerfmMatchEvt evt=scorePerfmMatch.evts[n];
		int ditchHeight=SitchToSitchHeight(evt.sitch); //0=C4 <-> yoffset+5*staffLineSpace
		int acc=SitchToAcc(evt.sitch);//0=natural 1=sharp ...

		double onPos=4*xoffset+pxPerSec*evt.ontime-pxPerSec*int(evt.ontime/secPerLine)*secPerLine;
		double offPos=4*xoffset+pxPerSec*evt.offtime-pxPerSec*int(evt.offtime/secPerLine)*secPerLine;
		int onLine=int(evt.ontime/secPerLine);
		int offLine=int(evt.offtime/secPerLine);

		perfmItemID[n][1]=numItems;
		drawNote(onLine,offLine,onPos,offPos,ditchHeight,acc,evt.onvel,yoffset2,evt.errorInd);

		itemID.push_back(numItems);
		perfmItemID[n][0]=numItems;

		if(evt.fmt1ID[0]=='*' || evt.fmt1ID[0]=='&'){
			DrawFmt1ID(2,onPos,ditchHeight,Simplifyfmt1ID(evt.fmt1ID),1);
		}else{
			DrawFmt1ID(2,onPos,ditchHeight,Simplifyfmt1ID(evt.fmt1ID),0);
		}//endif
	}//endfor n
	perfmSegmentIds.push_back(scorePerfmMatch.evts.size());

////// Draw score notes and matching lines

	PianoRoll  scorePianoRoll;//Used only as a piano roll
	vector<string> missingNoteFmt1IDs;
	for(int i=0;i<scorePerfmMatch.missingNotes.size();i+=1){
		missingNoteFmt1IDs.push_back(scorePerfmMatch.missingNotes[i].fmt1ID);
	}//endfor i

	for(int seg=0;seg<perfmSegmentIds.size()-1;seg+=1){
		int maxStime = -1;
		int minStime = score.evts[score.evts.size()-1].stime+1;
		double maxTref = scorePerfmMatch.evts[0].ontime;
		double minTref = scorePerfmMatch.evts[scorePerfmMatch.evts.size()-1].ontime;
		int minRef=-1;
		for(int n=perfmSegmentIds[seg];n<=perfmSegmentIds[seg+1]&&n<scorePerfmMatch.evts.size();n+=1){
			if(scorePerfmMatch.evts[n].errorInd>1){continue;}
			if(scorePerfmMatch.evts[n].stime>maxStime){
				maxStime=scorePerfmMatch.evts[n].stime;
				maxTref=scorePerfmMatch.evts[n].ontime;
			}//endif
			if(scorePerfmMatch.evts[n].stime<minStime){
				minStime=scorePerfmMatch.evts[n].stime;
				minTref=scorePerfmMatch.evts[n].ontime;
				minRef=n;
			}//endif
		}//endfor n
		double vref=(maxTref-minTref)/(maxStime-minStime);

		if(maxStime<scorePerfmMatch.evts[scorePerfmMatch.evts.size()-1].stime){
			maxStime-=1;
			maxTref-=vref;
		}//endif

		Fmt3x drawedScore=score.SubScore(minStime,maxStime);

		PianoRollEvt prEvt;
		prEvt.channel=0;
		prEvt.onvel=100;
		prEvt.offvel=100;

		/// Draw score notes
		vector<double> scoreNoteOnPos;
		vector<int> scoreNoteDitchHeight;
		vector<int> scoreStime;//Score-time-wise matchingの表示に使うらしい
		vector<string> scoreNotefmt1ID;
		bool isAMissingNote=false;
		for(int n=0;n<drawedScore.evts.size();n+=1){

			Fmt3xEvt sevt=drawedScore.evts[n];
			if(sevt.eventtype=="rest"){
				continue;
			}else if(sevt.eventtype=="chord"){

				for(int i=0;i<sevt.numNotes;i+=1){
					bool isOrnament=false;
					string principleDitch;
					string auxiliaryDitch="";
					string ornamentInd="";
					if(sevt.sitches[i].find(',')!=string::npos){//if ornamented
						isOrnament=true;
						principleDitch=sevt.sitches[i].substr(0,sevt.sitches[i].find(','));
						string tmp=sevt.sitches[i].substr(sevt.sitches[i].find(',')+1);
						auxiliaryDitch=tmp.substr(0,tmp.find(','));
						stringstream ss;
						ss.str(""); ss<<sevt.notetypes[i].substr(0,sevt.notetypes[i].find('.'))<<"("<<sevt.sitches[i]<<")";
						ornamentInd=ss.str();
					}else{//if not ornamented
						principleDitch=sevt.sitches[i];
					}//endif

					int ditchHeight=SitchToSitchHeight(principleDitch); // 0=C4 <-> yoffset+5*staffLineSpace
					int acc=SitchToAcc(principleDitch); // 0=natural 1=sharp ...
					double onPos  = 4*xoffset+pxPerSec*(minTref+(sevt.stime-minStime)*vref+sevt.subOrder*graceNoteDuration);
					double offPos = 4*xoffset+pxPerSec*(minTref+(sevt.stime+sevt.dur-minStime)*vref);

					prEvt.ontime=(minTref+(sevt.stime-minStime)*vref+sevt.subOrder*graceNoteDuration);
					prEvt.offtime=(minTref+(sevt.stime+sevt.dur-minStime)*vref);
					prEvt.sitch=principleDitch;
					prEvt.pitch=SitchToPitch(prEvt.sitch);
					scorePianoRoll.evts.push_back(prEvt);

					scoreNoteDitchHeight.push_back(ditchHeight);
					scoreNoteOnPos.push_back(onPos);
					scoreNotefmt1ID.push_back(sevt.fmt1IDs[i]);
					scoreStime.push_back(sevt.stime);

					isAMissingNote=false;
					for(int k=0;k<missingNoteFmt1IDs.size();k+=1){
						if(missingNoteFmt1IDs[k]==sevt.fmt1IDs[i]){isAMissingNote=true; break;}
					}//endfor k

					drawNote(0,0,onPos,offPos,ditchHeight,acc,100,yoffset,((isAMissingNote)? -2:0));
					DrawFmt1ID(1,onPos,ditchHeight,Simplifyfmt1ID(sevt.fmt1IDs[i]),0);
{
					QGraphicsTextItem *item = new QGraphicsTextItem(QString::fromStdString(ornamentInd));
					if(isBigLetter){
						item->setFont(QFont("Times",textFontSize));
					}else{
						item->setFont(QFont("Times",0.6*textFontSize));
					}//endif
					item->setPos(onPos,yoffset+(4.5-0.5*ditchHeight-1.5)*staffLineSpace);
					item->setDefaultTextColor(QColor(0,0,0));
					AddItem(item);
}//

				}//endfor i

			}else if(sevt.eventtype=="tremolo"){
			}else if(sevt.eventtype=="short-app"){

				for(int i=0;i<sevt.numNotes;i+=1){

					int ditchHeight=SitchToSitchHeight(sevt.sitches[i]); // 0=C4 <-> yoffset+5*staffLineSpace
					int acc=SitchToAcc(sevt.sitches[i]); // 0=natural 1=sharp ...
					double onPos  = 4*xoffset+pxPerSec*(minTref+(sevt.stime-minStime)*vref+sevt.subOrder*graceNoteDuration);
					double offPos = onPos+pxPerSec*graceNoteDuration;

					prEvt.ontime=(minTref+(sevt.stime-minStime)*vref)+sevt.subOrder*graceNoteDuration;
					prEvt.offtime=prEvt.ontime+graceNoteDuration;
					prEvt.sitch=sevt.sitches[i];
					prEvt.pitch=SitchToPitch(prEvt.sitch);
					scorePianoRoll.evts.push_back(prEvt);

					scoreNoteDitchHeight.push_back(ditchHeight);
					scoreNoteOnPos.push_back(onPos);
					scoreNotefmt1ID.push_back(sevt.fmt1IDs[i]);
					scoreStime.push_back(sevt.stime);

					isAMissingNote=false;
					for(int k=0;k<missingNoteFmt1IDs.size();k+=1){
						if(missingNoteFmt1IDs[k]==sevt.fmt1IDs[i]){isAMissingNote=true; break;}
					}//endfor k

					drawNote(0,0,onPos,offPos,ditchHeight,acc,100,yoffset,((isAMissingNote)? -2:0));
					DrawFmt1ID(1,onPos,ditchHeight,Simplifyfmt1ID(sevt.fmt1IDs[i]),0);
				}//endfor i

			}else if(sevt.eventtype=="after-note"){

				for(int i=0;i<sevt.numNotes;i+=1){

					int ditchHeight=SitchToSitchHeight(sevt.sitches[i]); // 0=C4 <-> yoffset+5*staffLineSpace
					int acc=SitchToAcc(sevt.sitches[i]); // 0=natural 1=sharp ...
					double onPos  = 4*xoffset+pxPerSec*(minTref+(sevt.stime-minStime)*vref+sevt.subOrder*graceNoteDuration);
					double offPos = onPos+pxPerSec*graceNoteDuration;

					prEvt.ontime=(minTref+(sevt.stime-minStime)*vref)+sevt.subOrder*graceNoteDuration;
					prEvt.offtime=prEvt.ontime+graceNoteDuration;
					prEvt.sitch=sevt.sitches[i];
					prEvt.pitch=SitchToPitch(prEvt.sitch);
					scorePianoRoll.evts.push_back(prEvt);

					scoreNoteDitchHeight.push_back(ditchHeight);
					scoreNoteOnPos.push_back(onPos);
					scoreNotefmt1ID.push_back(sevt.fmt1IDs[i]);
					scoreStime.push_back(sevt.stime);

					isAMissingNote=false;
					for(int k=0;k<missingNoteFmt1IDs.size();k+=1){
						if(missingNoteFmt1IDs[k]==sevt.fmt1IDs[i]){isAMissingNote=true; break;}
					}//endfor k

					drawNote(0,0,onPos,offPos,ditchHeight,acc,100,yoffset,((isAMissingNote)? -2:0));
					DrawFmt1ID(1,onPos,ditchHeight,Simplifyfmt1ID(sevt.fmt1IDs[i]),0);
				}//endfor i

			}else{
			}//endif

		}//endfor n


/////// // draw matching lines
    for(int n=perfmSegmentIds[seg];n<perfmSegmentIds[seg+1];n+=1){
      ScorePerfmMatchEvt evt=scorePerfmMatch.evts[n];
      if(evt.fmt1ID=="*" || evt.fmt1ID=="&"){continue;}//endif
      int scoreNotePos=-1;
      if(evt.fmt1ID[0]=='$'){
        for(int i=0;i<scoreNotefmt1ID.size();i+=1){
          if(evt.stime==scoreStime[i]){scoreNotePos=i; break;}//endif
        }//endfor i
        if(scoreNotePos<0){continue;}
        double onPos=4*xoffset+pxPerSec*evt.ontime;
        double y2=yoffset2+5*staffLineSpace-0.5*staffLineSpace*(SitchToSitchHeight(evt.sitch)+1);
        matchingLinePos[n][0]=scoreNoteOnPos[scoreNotePos];
        matchingLinePos[n][1]=yoffset+5*staffLineSpace-0.5*staffLineSpace*(SitchToSitchHeight("C6")+1)+staffLineSpace;
        matchingLinePos[n][2]=scoreNoteOnPos[scoreNotePos];
        matchingLinePos[n][3]=yoffset+5*staffLineSpace-0.5*staffLineSpace*(SitchToSitchHeight("G1")+1)+staffLineSpace;
        matchingLinePos[n][4]=onPos;
        matchingLinePos[n][5]=y2;
        matchingLinePos[n][6]=onPos+0.6*staffLineSpace;
        matchingLinePos[n][7]=y2;
        scoreNotePos=-1;
      }else{//if note-wise matched
        for(int i=0;i<scoreNotefmt1ID.size();i+=1){
          if(evt.fmt1ID==scoreNotefmt1ID[i]){scoreNotePos=i; break;}//endif
        }//endfor i
        if(scoreNotePos<0){continue;}
        double onPos=4*xoffset+pxPerSec*evt.ontime;
        double y1=yoffset+5*staffLineSpace-0.5*staffLineSpace*(scoreNoteDitchHeight[scoreNotePos]+1)+staffLineSpace;
        double y2=yoffset2+5*staffLineSpace-0.5*staffLineSpace*(SitchToSitchHeight(evt.sitch)+1);
        matchingLinePos[n][0]=scoreNoteOnPos[scoreNotePos]+0.6*staffLineSpace;
        matchingLinePos[n][1]=y1;
        matchingLinePos[n][2]=scoreNoteOnPos[scoreNotePos];
        matchingLinePos[n][3]=y1;
        matchingLinePos[n][4]=onPos;
        matchingLinePos[n][5]=y2;
        matchingLinePos[n][6]=onPos+0.6*staffLineSpace;
        matchingLinePos[n][7]=y2;
      }//endif
{
      QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[n][0],matchingLinePos[n][1],matchingLinePos[n][2],matchingLinePos[n][3]);
      item->setPen(QPen(QBrush(lineColor(scoreNotePos)),((scoreNotePos<0)? 4:2)));
      item->setFlag(QGraphicsItem::ItemIsSelectable);
      perfmItemID[n][3]=numItems;
      AddItem(item);
}{
      QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[n][2],matchingLinePos[n][3],matchingLinePos[n][4],matchingLinePos[n][5]);
      item->setPen(QPen(QBrush(lineColor(scoreNotePos)),2));
      perfmItemID[n][4]=numItems;
      AddItem(item);
}{
      QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[n][4],matchingLinePos[n][5],matchingLinePos[n][6],matchingLinePos[n][7]);
      item->setPen(QPen(QBrush(lineColor(scoreNotePos)),2));
      perfmItemID[n][5]=numItems;
      AddItem(item);
}
    }//endfor n

  }//endfor seg

  scoreMidi=scorePianoRoll.ToMidi();
  // vvvvvvvvvv Changed by Nishikimi vvvvvvvvvvv
  // Set Score MIDI to player.
  this->setScoreMidiToPlayer();

  int bar_x = 4 * xoffset;
  int bar_y = yoffset - 10*staffLineSpace;
  int bar_w = (numOfLines > 1 ? width : widthLast) - 3 * xoffset;
  int bar_h = yoffset2 + (numOfLines-1) * heightPerLine + 20 * staffLineSpace - bar_y;
  this->scrollBar = new ScrollBar(bar_x, bar_y, bar_w, bar_h, pxPerSec);
  connect(this->scrollBar, SIGNAL(finished()),
          this, SLOT(on_PlayIsFinished()));

  AddItem(this->scrollBar->getPtr());
  // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

  show();

}//end drawScorePerfmMatch

void EditWindow::drawNote(int onLine_,int offLine_, double onPos_, double offPos_, int ditchHeight_,int acc_,int onvel_,double yoffset_,int errorInd){
    if(onLine_==offLine_){
{
      QGraphicsRectItem* item = new QGraphicsRectItem(onPos_,(onLine_*heightPerLine+yoffset_+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight_+1)),(offPos_-onPos_),staffLineSpace);
      item->setBrush(QBrush(accToColor(acc_)));
      item->setPen(Qt::NoPen);
      item->setOpacity(0.4*pow(onvel_/128.,0.5));
      item->setFlag(QGraphicsItem::ItemIsSelectable);
      AddItem(item);
}{
			QGraphicsRectItem* item = new QGraphicsRectItem(onPos_,(onLine_*heightPerLine+yoffset_+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight_+1)),(offPos_-onPos_),staffLineSpace);
			if(errorInd==0){//correct
				item->setPen(QPen(QBrush(Qt::black),1));
			}else if(errorInd==1){//pitch error
				item->setPen(QPen(QBrush(QColor(255,69,0)),8));
			}else if(errorInd==2){//Extra note (note-wise,&)
				item->setPen(QPen(QBrush(QColor(0,255,0)),8));
			}else if(errorInd==3){//Extra note (cluster-wise,*)
				item->setPen(QPen(QBrush(QColor(0,255,255)),8));//rgb(210,105,30)
			}else if(errorInd==-2){//Missing
				item->setPen(QPen(QBrush(QColor(255,0,255)),9));//rgb(0,255,127)//rgb(255,69,0)//(240,240,0)
			}else if(errorInd==4){//timing??
				item->setPen(QPen(QBrush(Qt::black),8));
			}else if(errorInd==-1){//unmatched??
			//        item->setPen(QPen(QBrush(QColor(200,100,50)),8));
				item->setPen(QPen(QBrush(Qt::black),1));
			}else{
				item->setPen(QPen(QBrush(Qt::black),1));
			}//endif
			item->setBrush(Qt::NoBrush);
			AddItem(item);
}{
      QGraphicsTextItem *item = new QGraphicsTextItem(QString::fromStdString(accToSymbol(acc_)));
      item->setFont(QFont("Kousaku",accFontSize));
      item->setPos(onPos_-0.9*staffLineSpace,onLine_*heightPerLine+yoffset_+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight_+1)+staffLineSpace-0.5*staffLineSpace-accFontSize+YOFF_acc);
      AddItem(item);
}
//ofs<<"<text font-family=\"'Kousaku'\" transform=\"translate("<<(onPos)<<","<<(onLine*heightPerLine+yoffset+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight+1)+staffLineSpace-0.5*staffLineSpace)<<")\" font-size=\""<<0.5*accFontSize<<"\" fill=\"red\">"<<dprEvt.ID<<"</text>\n";
      addLedgerLine(ditchHeight_,onPos_,onLine_*heightPerLine+yoffset_);
    }//endif
}//end drawNote

void EditWindow::addLedgerLine(int ditchHeight,double onPos_,double yoffset_){
  if(ditchHeight==0){//Middle C
    QGraphicsLineItem *item = new QGraphicsLineItem(onPos_-0.5*staffLineSpace,yoffset_+5*staffLineSpace,onPos_+0.5*staffLineSpace,yoffset_+5*staffLineSpace);
    AddItem(item);
  }else if(ditchHeight>=12){
    for(int i=12;i<=ditchHeight;i+=2){//Upper ledger lines
      QGraphicsLineItem *item = new QGraphicsLineItem(onPos_-0.5*staffLineSpace,yoffset_+5*staffLineSpace-0.5*staffLineSpace*i,onPos_+0.5*staffLineSpace,yoffset_+5*staffLineSpace-0.5*staffLineSpace*i);
      item->setPen(QPen(((i<=20)? Qt::black : Qt::blue)));
      AddItem(item);
    }//endfor i
  }else if(ditchHeight<=-12){//Lower ledger lines
    for(int i=-12;i>=ditchHeight;i-=2){
      QGraphicsLineItem *item = new QGraphicsLineItem(onPos_-0.5*staffLineSpace,yoffset_+5*staffLineSpace-0.5*staffLineSpace*i,onPos_+0.5*staffLineSpace,yoffset_+5*staffLineSpace-0.5*staffLineSpace*i);
      item->setPen(QPen(((i>=-20)? Qt::black : Qt::blue)));
      AddItem(item);
    }//endfor i
  }//endif
}//end addLedgerLine

void EditWindow::DrawFmt1ID(int staffNum_,double onPos_, int ditchHeight_,string text_,int colorInd_=0){
	//staffNum_ = 1 for score, staffNum_ = for performance
	QGraphicsTextItem *item = new QGraphicsTextItem(QString::fromStdString(text_));
	if(isBigLetter){
		item->setFont(QFont("Times",textFontSize));
	}else{
		item->setFont(QFont("Times",0.6*textFontSize));
	}//endif
	if(staffNum_==2){
		item->setPos(onPos_,yoffset2+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight_+1));
		item->setTextInteractionFlags(Qt::TextEditorInteraction);
		item->setTabChangesFocus(true);
	}else{
		item->setPos(onPos_,yoffset+5*staffLineSpace-0.5*staffLineSpace*(ditchHeight_+1));
	}//endif
	if(colorInd_==0){
		item->setDefaultTextColor(QColor(0,120,255));
	}else{
		item->setDefaultTextColor(QColor(255,0,0));
	}//endif
	AddItem(item);
}//end DrawFmt1ID

void EditWindow::drawStaffLines(double yoffset_){
  for(int k=0;k<numOfLines;k+=1){
    for(int i=0;i<=10;i+=1){
      if(i==5){continue;}
      QGraphicsLineItem *item = new QGraphicsLineItem(xoffset,k*heightPerLine+yoffset_+i*staffLineSpace,xoffset+((k==numOfLines-1)? widthLast:width),k*heightPerLine+yoffset_+i*staffLineSpace);
      item->setPen(QPen(QBrush(Qt::black),1));
      AddItem(item);
    }//endfor i
{
    QGraphicsTextItem *item = new QGraphicsTextItem("&");
    item->setFont(QFont("Kousaku",clefFontSize));
    item->setPos(2*xoffset,k*heightPerLine+yoffset_+3*staffLineSpace-clefFontSize+YOFF_clef);
    AddItem(item);
}{
    QGraphicsTextItem *item = new QGraphicsTextItem("?");
    item->setFont(QFont("Kousaku",clefFontSize));
    item->setPos(2*xoffset,k*heightPerLine+yoffset_+7*staffLineSpace-clefFontSize+YOFF_clef);
    AddItem(item);
}//
  }//endfor k
}//end drawStaffLines

void EditWindow::drawTimeLines(double yoffset_){
  for(int k=0;k<numOfLines;k+=1){
    stringstream ss;
    for(int i=0;i<=((k!=numOfLines-1)? secPerLine:endtime-int(endtime/secPerLine)*secPerLine);i+=1){
      QGraphicsLineItem *item = new QGraphicsLineItem(4*xoffset+i*pxPerSec,k*heightPerLine+yoffset_+0*staffLineSpace,4*xoffset+i*pxPerSec,k*heightPerLine+yoffset_+10*staffLineSpace);
			item->setPen(QPen(QBrush(QColor(147,112,219)),1));
      AddItem(item);

      ss.str(""); ss<<(k*secPerLine+i);
      QGraphicsTextItem *item2 = new QGraphicsTextItem(QString::fromStdString(ss.str()));
      item2->setFont(QFont("Times",1*staffLineSpace));
      item2->setPos(4*xoffset+i*pxPerSec-0.5*staffLineSpace,k*heightPerLine+yoffset_+0*staffLineSpace-0.5*staffLineSpace-1.*staffLineSpace+YOFF_time);
      item2->setDefaultTextColor(QColor(147,112,219));
      AddItem(item2);
    }//endfor i
  }//endfor k
}//end drawTimeLines



void EditWindow::CreateActions(){

	openScoreAct = new QAction(tr("Open(Score fmt3x)"), this);
	openScoreAct->setStatusTip(tr("Open a score fmt3x file"));
	connect(openScoreAct, SIGNAL(triggered()), this, SLOT(OpenScore()));

	openMatchAct = new QAction(tr("Open(Match)"), this);
	openMatchAct->setStatusTip(tr("Open a match file"));
	connect(openMatchAct, SIGNAL(triggered()), this, SLOT(OpenMatch()));

	reloadAct = new QAction(tr("Reload"), this);
	reloadAct->setStatusTip(tr("Reload a match file"));
	connect(reloadAct, SIGNAL(triggered()), this, SLOT(Reload()));

	saveAct = new QAction(tr("Save"), this);
	saveAct->setStatusTip(tr("Save in a file"));
	connect(saveAct, SIGNAL(triggered()), this, SLOT(Save()));

	printAct = new QAction(tr("Print"), this);
	printAct->setStatusTip(tr("Print the current scene"));
	connect(printAct, SIGNAL(triggered()), this, SLOT(Print()));

	enlargeTimeAxis = new QAction(tr("+"), this);
	printAct->setStatusTip(tr("Larger time axis"));
	connect(enlargeTimeAxis, SIGNAL(triggered()), this, SLOT(LargerTimeAxis()));

	reduceTimeAxis = new QAction(tr("-"), this);
	printAct->setStatusTip(tr("Smaller time axis"));
	connect(reduceTimeAxis, SIGNAL(triggered()), this, SLOT(SmallerTimeAxis()));

	isBigLetter=true;

	letterSizeSwitchAct = new QAction(tr("Big letter"), this);
	letterSizeSwitchAct->setStatusTip(tr("Letter Size Change"));
	connect(letterSizeSwitchAct, SIGNAL(triggered()), this, SLOT(LetterSizeSwitchClicked()));

	segmentOffset=0;
	segmentSize=30;

	switchSegmentPos = new QAction(tr("Switch"), this);
	switchSegmentPos->setStatusTip(tr("Segment Pos Change"));
	connect(switchSegmentPos, SIGNAL(triggered()), this, SLOT(SegmentPosChanged()));

}//end CreateActions

void EditWindow::CreateToolBars(){

	fileToolBar = addToolBar(tr("File"));
	fileToolBar->addAction(openScoreAct);
	fileToolBar->addAction(openMatchAct);
	fileToolBar->addAction(reloadAct);
	fileToolBar->addAction(saveAct);

	editToolBar = addToolBar(tr("Edit"));
	editToolBar->addAction(printAct);
	editToolBar->addAction(reduceTimeAxis);
	editToolBar->addAction(enlargeTimeAxis);
	editToolBar->addAction(letterSizeSwitchAct);
	editToolBar->addAction(switchSegmentPos);

  portCombo = new QComboBox;
  portCombo->setFocusPolicy(Qt::FocusPolicy::NoFocus);
  vector<string> portnames(player.controller_.getOutputPortNameList());
  if (portnames.size() == 0) {
    portCombo->addItem(("-- No MIDI Output Port --"));
  } else {
    for (int i = 0; i < portnames.size(); i++) {
      portCombo->addItem(QString::fromStdString(portnames[i]));
    }
    player.selectOutputDevise(0);
  }
  connect(portCombo, SIGNAL(currentIndexChanged(int)),
          this, SLOT(on_PortComboIndexChanged(int)));
  portToolBar = addToolBar(tr("Port"));
  portToolBar->addWidget(portCombo);


  this->isPlaying = false;
  this->isChannelScore = true;

  channelSwitchButton = new QPushButton();
  startButton  = new QPushButton();
  resumeButton = new QPushButton();

  channelSwitchButton->setObjectName("ChannelSwitch");
  channelSwitchButton->setText("Score");
  channelSwitchButton->setFocusPolicy(Qt::FocusPolicy::NoFocus);
  connect(channelSwitchButton, SIGNAL(clicked(bool)),
          this, SLOT(on_ChannelSwitchClicked()));

  startButton->setObjectName("Start");
  startButton->setText("Start");
  startButton->setFocusPolicy(Qt::FocusPolicy::NoFocus);
  connect(startButton, SIGNAL(clicked()), this, SLOT(on_StartClicked()));

  resumeButton->setObjectName("Resume");
  resumeButton->setText("Resume");
  resumeButton->setFocusPolicy(Qt::FocusPolicy::NoFocus);
  connect(resumeButton, SIGNAL(clicked()), this, SLOT(on_ResumeClicked()));


  startTimeLineEdit = new QLineEdit();
  startTimeLineEdit->setObjectName("StartTimeEdit");
  startTimeLineEdit->setValidator(new QDoubleValidator(0, 9999, 4));
  startTimeLineEdit->setText("0.0");
  startTimeLineEdit->setFocusPolicy(Qt::FocusPolicy::ClickFocus);
  // startTimeLineEdit->setFocusPolicy(Qt::FocusPolicy::NoFocus);
  // startTimeLineEdit->setMaximumWidth(100);
  startTimeLineEdit->setFixedWidth(50);

  startbuttonToolBar = addToolBar(tr("Start Button"));
  startbuttonToolBar->addWidget(startTimeLineEdit);
  startbuttonToolBar->addWidget(startButton);
  startbuttonToolBar->addWidget(resumeButton);
  startbuttonToolBar->addWidget(channelSwitchButton);

}//end CreateToolBars

void EditWindow::OpenMatch(){
//cout<<"open file"<<endl;
  OpenMatchFile();
}//OpenMatch

void EditWindow::OpenScore(){
//cout<<"open file"<<endl;
  OpenScoreFile();
}//Open

void EditWindow::Reload(){
  ReloadFile();
}//Reload

void EditWindow::Save(){
  QString file = QFileDialog::getSaveFileName(this,"Save File");
  if(file.toStdString()!=""){//if not cancelled
    SaveFile(file.toStdString());
  }//endif
}//Save

void EditWindow::Print(){
  QString file = QFileDialog::getSaveFileName(this,tr("Save PDF File"),"Untitled.pdf",tr("PDF files (*.pdf)"));
  if(file!=""){//if not cancelled
    PrintView(file);
  }//endif
}//Print

void EditWindow::LargerTimeAxis(){
	pxPerSec*=1.2;
	drawScorePerfmMatch();
	QPointF center = m_view->mapToScene(m_view->viewport()->rect().center());
	m_view->centerOn(1.2*center.x(),center.y());
}//LargerTimeAxis
void EditWindow::SmallerTimeAxis(){
	pxPerSec/=1.2;
	drawScorePerfmMatch();
	QPointF center = m_view->mapToScene(m_view->viewport()->rect().center());
	m_view->centerOn(center.x()/1.2,center.y());
}//SmallerTimeAxis

void EditWindow::MySelected(){
  QList<QGraphicsItem *> items=m_scene->items();
  QGraphicsItem *focusedItem=m_scene->focusItem();
  int curID=-1;
  for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
    if(items[numItems-1-perfmItemID[n][0]]==focusedItem){curID=n;break;}
  }//endfor n
  if(curID<0){
    QList<QGraphicsItem *> sele_items=m_scene->selectedItems();
    if(sele_items.size()>0){
      for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
        if(items[numItems-1-perfmItemID[n][0]]==sele_items[0]){curID=n;break;}
        if(items[numItems-1-perfmItemID[n][1]]==sele_items[0]){curID=n;break;}
        if(items[numItems-1-perfmItemID[n][3]]==sele_items[0]){curID=n;break;}
      }//endfor n
    }//endif
  }//endif
  Unstress();
  if(curID>=0){
    Stress(curID);
  }//endif
}//end MySelected

void EditWindow::Stress(int perfmID){
  if(perfmID<0 || perfmID>=scorePerfmMatch.evts.size()){return;}
{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][0],matchingLinePos[perfmID][1],matchingLinePos[perfmID][2],matchingLinePos[perfmID][3]);
//  item->setPen(QPen(QBrush(QColor(255,0,124)),10));
  item->setPen(QPen(QBrush(QColor(0,200,255)),10));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][2],matchingLinePos[perfmID][3],matchingLinePos[perfmID][4],matchingLinePos[perfmID][5]);
//  item->setPen(QPen(QBrush(QColor(255,0,124)),10));
  item->setPen(QPen(QBrush(QColor(0,200,255)),10));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][4],matchingLinePos[perfmID][5],matchingLinePos[perfmID][6],matchingLinePos[perfmID][7]);
//  item->setPen(QPen(QBrush(QColor(255,0,124)),10));
  item->setPen(QPen(QBrush(QColor(0,200,255)),10));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][0],matchingLinePos[perfmID][1],matchingLinePos[perfmID][2],matchingLinePos[perfmID][3]);
  item->setPen(QPen(QBrush(QColor(0,0,0)),2));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][2],matchingLinePos[perfmID][3],matchingLinePos[perfmID][4],matchingLinePos[perfmID][5]);
  item->setPen(QPen(QBrush(QColor(0,0,0)),2));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}{
  QGraphicsLineItem *item = new QGraphicsLineItem(matchingLinePos[perfmID][4],matchingLinePos[perfmID][5],matchingLinePos[perfmID][6],matchingLinePos[perfmID][7]);
  item->setPen(QPen(QBrush(QColor(0,0,0)),2));
  stressedItemNums.push_back(numItems);
  AddItem(item);
}
  QList<QGraphicsItem *> items=m_scene->items();
  items[numItems-1-perfmItemID[perfmID][0]]->setFocus();
}//end Stress

void EditWindow::Unstress(){
  for(int i=stressedItemNums.size()-1;i>=0;i-=1){
    RemoveItem(stressedItemNums[i]);
  }//endfor i
  stressedItemNums.clear();
}//end Unstress


void EditWindow::Pressed_Greater(){
  m_view->scale(1/1.2,1/1.2);
//  qDebug() << "Pressed_Greater";
}
void EditWindow::Pressed_Less(){
  m_view->scale(1.2,1.2);
//  qDebug() << "Pressed_Less";
}
void EditWindow::Pressed_Tab(){
//cout<<"pressed tab"<<endl;
  QGraphicsItem *focusedItem=m_scene->focusItem();
  QList<QGraphicsItem *> items=m_scene->items();
  int curID=-1;
  for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
    if(items[numItems-1-itemID[n]]==focusedItem){curID=n;break;}
  }//endfor n
  if(curID>=0 && curID<scorePerfmMatch.evts.size()-1){
    m_scene->setFocusItem(items[numItems-1-itemID[curID+1]]);
  }//endif
  MySelected();
}

void EditWindow::Pressed_ShiftTab(){
//cout<<"pressed shift tab"<<endl;
  QGraphicsItem *focusedItem=m_scene->focusItem();
  QList<QGraphicsItem *> items=m_scene->items();
  int curID=-1;
  for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
    if(items[numItems-1-itemID[n]]==focusedItem){curID=n;break;}
  }//endfor n
  if(curID>=1 && curID<scorePerfmMatch.evts.size()){
    m_scene->setFocusItem(items[numItems-1-itemID[curID-1]]);
  }//endif
  MySelected();
}

void EditWindow::LetterSizeSwitchClicked(){
	isBigLetter ^= true;
	if(isBigLetter){
		letterSizeSwitchAct->setText(tr("Big letter"));
	}else{
		letterSizeSwitchAct->setText(tr("Small letter"));
	}//endif
	drawScorePerfmMatch();
}//end LetterSizeSwitchClicked

void EditWindow::SegmentPosChanged(){
	if(segmentOffset==0&&segmentSize==30){
		segmentOffset=15;
		segmentSize=30;
	}else if(segmentOffset==15&&segmentSize==30){
		segmentOffset=15;
		segmentSize=100;
	}else if(segmentOffset==15&&segmentSize==100){
		segmentOffset=65;
		segmentSize=100;
	}else if(segmentOffset==65&&segmentSize==100){
		segmentOffset=0;
		segmentSize=100000;
	}else if(segmentOffset==0&&segmentSize==100000){
		segmentOffset=0;
		segmentSize=30;
	}else{
		segmentOffset=0;
		segmentSize=30;
	}//endif
	drawScorePerfmMatch();
}//end SegmentPosChanged

void EditWindow::Pressed_Save(){
//cout<<"pressed save"<<endl;
  SaveFile(curSaveFilename);
}

void EditWindow::Pressed_Print(){
//cout<<"pressed print"<<endl;
  PrintView(curPrintFilename);
}

void EditWindow::Pressed_Divide(){
//	cout<<"pressed divide"<<endl;
	Divide();
}
void EditWindow::OpenMatchFile(){
//cout<<filename<<endl;
  QString file = QFileDialog::getOpenFileName(this,"Open File");
  if(file!=""){//if not cancelled
    scorePerfmMatch.ReadFile(file.toStdString());
    curMatchFile=file.toStdString();
		PianoRoll pr;
		PianoRollEvt prEvt;
		for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
			prEvt.ID=scorePerfmMatch.evts[n].ID;
			prEvt.ontime=scorePerfmMatch.evts[n].ontime;
			prEvt.offtime=scorePerfmMatch.evts[n].offtime;
			prEvt.sitch=scorePerfmMatch.evts[n].sitch;
			prEvt.pitch=SitchToPitch(prEvt.sitch);
			prEvt.onvel=scorePerfmMatch.evts[n].onvel;
			prEvt.offvel=scorePerfmMatch.evts[n].offvel;
			prEvt.channel=scorePerfmMatch.evts[n].channel;
			pr.evts.push_back(prEvt);
		}//endfor n
    perfmMidi=pr.ToMidi();
    drawScorePerfmMatch();
    curSaveFilename="";
    // Set Perfm MIDI to player
    this->setPerfmMidiToPlayer();
  }//endif
}//end OpenMatchFile

void EditWindow::OpenScoreFile(){
//cout<<filename<<endl;
  QString file = QFileDialog::getOpenFileName(this,"Open File");
  if(file!=""){//if not cancelled
    score.ReadFile(file.toStdString());
    curScoreFile=file.toStdString();
  }//endif
}//end OpenScoreFile

void EditWindow::PrintView(QString file){
  if(file==""){
    QString newfile = QFileDialog::getSaveFileName(this,tr("Save PDF File"),"Untitled.pdf",tr("PDF files (*.pdf)"));
    curPrintFilename=newfile;
  }else{
    curPrintFilename=file;
  }//endif

  if(curPrintFilename==""){return;}//endif

  QPrinter printer(QPrinter::HighResolution);
  printer.setPageSize(QPrinter::A4);
  printer.setOutputFormat(QPrinter::PdfFormat);
  printer.setOutputFileName(curPrintFilename);
  QPainter painter(&printer);
  m_view->render(&painter);
}

void EditWindow::SaveFile(string filename){
//  qDebug() << "savesave";

  if(filename==""){
    QString file = QFileDialog::getSaveFileName(this,"Save File");
    curSaveFilename=file.toStdString();
  }else{
    curSaveFilename=filename;
  }//endif

  if(curSaveFilename==""){return;}//endif

  ScorePerfmMatch pre_scorePerfmMatch=scorePerfmMatch;/////////////

	vector<string> replacedFmt1IDs;//To be candidates of missing notes
	QList<QGraphicsItem *> items=m_scene->items();
	for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
		QGraphicsTextItem *item=dynamic_cast<QGraphicsTextItem*>(items[numItems-1-perfmItemID[n][0]]);
		string curText=(item->toPlainText()).toStdString();
		string curfmt1ID;

		if(curText.size()==0){//Typo
			//Do nothing (retain the original information)
		}else if(curText[0]=='&'){//Extra note (note-wise)
			if(scorePerfmMatch.evts[n].fmt1ID!="&"&&scorePerfmMatch.evts[n].fmt1ID!="*"){
				replacedFmt1IDs.push_back(scorePerfmMatch.evts[n].fmt1ID);
			}//endif
			scorePerfmMatch.evts[n].fmt1ID="&";
			scorePerfmMatch.evts[n].errorInd=2;
		}else if(curText[0]=='*'){//Extra note (cluster-wise)
			if(scorePerfmMatch.evts[n].fmt1ID!="&"&&scorePerfmMatch.evts[n].fmt1ID!="*"){
				replacedFmt1IDs.push_back(scorePerfmMatch.evts[n].fmt1ID);
			}//endif
			scorePerfmMatch.evts[n].fmt1ID="*";
			scorePerfmMatch.evts[n].errorInd=3;
		}else{//With fmt1ID -> correct note or pitch error
			curfmt1ID=Completefmt1ID(curText);
			if(curfmt1ID==scorePerfmMatch.evts[n].fmt1ID){//Not changed -> Do nothing
			}else{
				if(scorePerfmMatch.evts[n].fmt1ID!="&"&&scorePerfmMatch.evts[n].fmt1ID!="*"){
					replacedFmt1IDs.push_back(scorePerfmMatch.evts[n].fmt1ID);
				}//endif
				vector<int> scorePos=score.FindFmt3xScorePos(curfmt1ID);
				if(scorePos[0]>=0){
					scorePerfmMatch.evts[n].stime=score.evts[scorePos[0]].stime;
					int pos=-1;
					for(int k=2;k<scorePos.size();k+=1){
						if(scorePos[k]==SitchToPitch(scorePerfmMatch.evts[n].sitch)){pos=k;}//endif
					}//endfor k
					if(pos>0){
						scorePerfmMatch.evts[n].errorInd=0;
					}else{
						scorePerfmMatch.evts[n].errorInd=1;
					}//endif
					scorePerfmMatch.evts[n].fmt1ID=curfmt1ID;
				}else{//This is unexpected
					scorePerfmMatch.evts[n].stime=-1;
					scorePerfmMatch.evts[n].fmt1ID="*";
					scorePerfmMatch.evts[n].errorInd=3;
				}//endif
			}//endif
		}//endif

	}//endfor n

	/// Check missing note again
	for(int i=scorePerfmMatch.missingNotes.size()-1;i>=0;i-=1){
		for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
			if(scorePerfmMatch.evts[n].fmt1ID==scorePerfmMatch.missingNotes[i].fmt1ID){
				scorePerfmMatch.missingNotes.erase(scorePerfmMatch.missingNotes.begin()+i);
				break;
			}//endif
		}//endfor n
	}//endfor i
	MissingNote missingNote;
	for(int i=0;i<replacedFmt1IDs.size();i+=1){
		bool found=false;
		for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
			if(scorePerfmMatch.evts[n].fmt1ID==replacedFmt1IDs[i]){
				found=true;
				break;
			}//endif
		}//endfor n
		if(!found){
			missingNote.fmt1ID=replacedFmt1IDs[i];
			vector<int> scorePos=score.FindFmt3xScorePos(missingNote.fmt1ID);
			if(scorePos[0]>=0){
				missingNote.stime=score.evts[scorePos[0]].stime;
				scorePerfmMatch.missingNotes.push_back(missingNote);
			}//endif
		}//endif
	}//endfor i

	scorePerfmMatch.WriteFile(curSaveFilename);
	usleep(30000);
	drawScorePerfmMatch();
}//end SaveFile

void EditWindow::ReloadFile(){
	Unstress();
	m_scene->clearFocus();
	m_scene->clearSelection();
	if(curMatchFile!=""){//if not cancelled
		scorePerfmMatch.ReadFile(curMatchFile);
		drawScorePerfmMatch();
	}//endif
}//end ReloadFile

void EditWindow::Divide(){
//	cout<<"pressed divide"<<endl;
	QList<QGraphicsItem *> items=m_scene->items();
	QGraphicsItem *focusedItem=m_scene->focusItem();
	int curID=-1;
	for(int n=0;n<scorePerfmMatch.evts.size();n+=1){
		if(items[numItems-1-perfmItemID[n][0]]==focusedItem){curID=n;break;}
	}//endfor n
	if(curID<0 || curID>=scorePerfmMatch.evts.size()){return;}
	if(scorePerfmMatch.evts[curID].skipInd=="-"){
		scorePerfmMatch.evts[curID].skipInd="+";
	}else{
		scorePerfmMatch.evts[curID].skipInd="-";
	}//endif
	Unstress();
//	cout<<scorePerfmMatch.evts[curID].ontime<<endl;
	m_scene->clearFocus();
	m_scene->clearSelection();
	drawScorePerfmMatch();
}//end Divide

void EditWindow::on_ChannelSwitchClicked()
{
  if (this->isChannelScore) {
    this->channelSwitchButton->setText("Perfm");
  } else {
    this->channelSwitchButton->setText("Score");
  }
  this->isChannelScore ^= true;
}

void EditWindow::on_StartClicked()
{
  if (this->isPlaying) {
    this->startButton->setText("Start");
    this->stopScrollBar();
    this->player.stop();
    this->enableStartButton();
  } else {
    this->startButton->setText("Stop");
    this->channelSwitchButton->setEnabled(false);
    this->resumeButton->setEnabled(false);
    this->startScrollBar((int)(this->startTimeLineEdit->text().toDouble() * 1000));
//
	QPointF center = m_view->mapToScene(m_view->viewport()->rect().center());
	m_view->centerOn(4*xoffset+pxPerSec*(startTimeLineEdit->text().toDouble()+1),center.y());


    this->startMidi(this->startTimeLineEdit->text().toDouble());
  }
  this->isPlaying ^= true;
}


void EditWindow::on_ResumeClicked()
{
  std::cerr << "Resume" << std::endl;
  if (this->isPlaying) {
    this->resumeButton->setText("Resume");
    this->stopScrollBar();
    this->player.stop();
    this->enableStartButton();
  } else {
    this->resumeButton->setText("Stop");
    this->channelSwitchButton->setEnabled(false);
    this->startButton->setEnabled(false);
    this->startScrollBar((int)(this->player.getCurrentTime() * 1000));
    this->startMidi(this->player.getCurrentTime());
  }
  this->isPlaying ^= true;
}

void EditWindow::on_PortComboIndexChanged(int index)
{
  this->player.selectOutputDevise(index);
}

void EditWindow::on_PlayIsFinished()
{
  this->resumeButton->setText("Resume");
  this->startButton->setText("Start");
  this->stopScrollBar();
  this->player.stop();
  this->enableStartButton();
  this->resumeButton->setEnabled(false);
  this->isPlaying = false;
}


void EditWindow::startMidi(double startTimeInSec)
{
  int channel = (this->isChannelScore ? 0 : 1);
  this->player.soloOn(channel);
  this->player.start(startTimeInSec);
}


void EditWindow::setScoreMidiToPlayer()
{
  std::cerr << "Set Score MIDI" << std::endl;
  this->player.setMidi(this->scoreMidi, 0);
  this->player.muteOff(0);
}

void EditWindow::setPerfmMidiToPlayer()
{
  std::cerr << "Set Perfm MIDI" << std::endl;
  this->player.setMidi(this->perfmMidi, 1);
  this->player.muteOff(1);
}

void EditWindow::enableStartButton()
{
  std::cerr << "enable" << std::endl;
  this->channelSwitchButton->setEnabled(true);
  this->startButton->setEnabled(true);
  this->resumeButton->setEnabled(true);
}

void EditWindow::startScrollBar(int startTimeInMillisec)
{
  this->scrollBar->changePos(startTimeInMillisec);
  this->scrollBar->start();
}

void EditWindow::stopScrollBar()
{
  this->scrollBar->stop();
}


