#ifndef PIANOROLL_HPP
#define PIANOROLL_HPP

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cmath>
#include<cassert>
#include<algorithm>
#include"BasicPitchCalculation_v170101.hpp"
#include"Midi_v170101.hpp"
using namespace std;

class PianoRollEvt{
public:
	string ID;
	double ontime;
	double offtime;
	string sitch;//spelled pitch
	int pitch;//integral pitch
	int onvel;
	int offvel;
	int channel;

	PianoRollEvt(){}//end PianoRollEvt
	~PianoRollEvt(){}//end ~PianoRollEvt
};//end class PianoRollEvt

class PianoRoll{
public:
	vector<string> comments;
	vector<PianoRollEvt> evts;

	PianoRoll(){}//end PianoRoll
	~PianoRoll(){}//end ~PianoRoll

	void ReadFileSpr(string sprFile){
		comments.clear();
		evts.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;
		PianoRollEvt evt;
		ifstream ifs(sprFile.c_str());
		while(ifs>>s[0]){
			if(s[0][0]=='/'||s[0][0]=='#'){
				getline(ifs,s[99]);
				ss.str("");
				ss<<s[0]<<" "<<s[99];
				comments.push_back(ss.str());
				continue;
			}//endif
			evt.ID=s[0];
			ifs>>evt.ontime>>evt.offtime>>evt.sitch>>evt.onvel>>evt.offvel>>evt.channel;
			evt.pitch=SitchToPitch(evt.sitch);
			evts.push_back(evt);
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
	}//end ReadFileSpr

	void ReadFileOldSpr(string sprFile){
		comments.clear();
		evts.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;
		PianoRollEvt evt;
		ifstream ifs(sprFile.c_str());
		while(ifs>>s[0]){
			if(s[0][0]=='/'||s[0][0]=='#'){
				getline(ifs,s[99]);
				ss.str("");
				ss<<s[0]<<" "<<s[99];
				comments.push_back(ss.str());
				continue;
			}//endif
			evt.ID=s[0];
			ifs>>evt.ontime>>evt.offtime>>evt.sitch>>evt.onvel>>evt.offvel>>evt.channel;
			evt.sitch=OldSitchToSitch(evt.sitch);
			evt.pitch=SitchToPitch(evt.sitch);
			evts.push_back(evt);
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
	}//end ReadFileOldSpr

	void ReadFileIpr(string iprFile){//Note that pitch->sitch is not unique!
		comments.clear();
		evts.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;
		PianoRollEvt evt;
		ifstream ifs(iprFile.c_str());
		while(ifs>>s[0]){
			if(s[0][0]=='/'||s[0][0]=='#'){
				getline(ifs,s[99]);
				ss.str("");
				ss<<s[0]<<" "<<s[99];
				comments.push_back(ss.str());
				continue;
			}//endif
			evt.ID=s[0];
			ifs>>evt.ontime>>evt.offtime>>evt.pitch>>evt.onvel>>evt.offvel>>evt.channel;
			evt.sitch=PitchToSitch(evt.pitch);
			evts.push_back(evt);
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
	}//end ReadFileIpr

	void ReadMIDIFile(string midiFile){
		comments.clear();
		evts.clear();
		Midi midi;
		midi.ReadFile(midiFile);

		int onPosition[16][128];
		for(int i=0;i<16;i+=1)for(int j=0;j<128;j+=1){onPosition[i][j]=-1;}//endfor i,j
		PianoRollEvt evt;
		int curChan;

		for(int n=0;n<midi.content.size();n+=1){
			if(midi.content[n].mes[0]>=128 && midi.content[n].mes[0]<160){//note-on or note-off event
				curChan=midi.content[n].mes[0]%16;
				if(midi.content[n].mes[0]>=144 && midi.content[n].mes[2]>0){//note-on
					if(onPosition[curChan][midi.content[n].mes[1]]>=0){
cout<<"Warning: (Double) note-on event before a note-off event"<<endl;
						evts[onPosition[curChan][midi.content[n].mes[1]]].offtime=midi.content[n].time;
						evts[onPosition[curChan][midi.content[n].mes[1]]].offvel=-1;
					}//endif
					onPosition[curChan][midi.content[n].mes[1]]=evts.size();
					evt.channel=curChan;
					evt.sitch=PitchToSitch(midi.content[n].mes[1]);
					evt.pitch=midi.content[n].mes[1];
					evt.onvel=midi.content[n].mes[2];
					evt.offvel=0;
					evt.ontime=midi.content[n].time;
					evt.offtime=evt.ontime+0.1;
					evts.push_back(evt);
				}else{//note-off
					if(onPosition[curChan][midi.content[n].mes[1]]<0){
cout<<"Warning: Note-off event before a note-on event"<<endl;
						continue;
					}//endif
					evts[onPosition[curChan][midi.content[n].mes[1]]].offtime=midi.content[n].time;
					if(midi.content[n].mes[2]>0){
						evts[onPosition[curChan][midi.content[n].mes[1]]].offvel=midi.content[n].mes[2];
					}else{
						evts[onPosition[curChan][midi.content[n].mes[1]]].offvel=80;
					}//endif
					onPosition[curChan][midi.content[n].mes[1]]=-1;
				}//endif
			}//endif
		}//endfor n

		for(int i=0;i<16;i+=1)for(int j=0;j<128;j+=1){
			if(onPosition[i][j]>=0){
cout<<"Error: Note without a note-off event"<<endl;
cout<<"ontime channel sitch : "<<evts[onPosition[i][j]].ontime<<"\t"<<evts[onPosition[i][j]].channel<<"\t"<<evts[onPosition[i][j]].sitch<<endl;
				return;
			}//endif
		}//endfor i,j

		for(int n=0;n<evts.size();n+=1){
			stringstream ss;
			ss.str(""); ss<<n;
			evts[n].ID=ss.str();
		}//endfor n

	}//end ReadMIDIFile

	void WriteFileSpr(string outputFile){
		ofstream ofs(outputFile.c_str());
		ofs<<"//Version: PianoRoll_v170101"<<"\n";
		for(int i=0;i<comments.size();i+=1){
			ofs<<comments[i]<<endl;
		}//endfor i
		for(int n=0;n<evts.size();n+=1){
			PianoRollEvt evt=evts[n];
			ofs<<evt.ID<<"\t"<<evt.ontime<<"\t"<<evt.offtime<<"\t"<<evt.sitch<<"\t"<<evt.onvel<<"\t"<<evt.offvel<<"\t"<<evt.channel<<"\n";
		}//endfor n
		ofs.close();
	}//end WriteFileSpr

	void WriteFileIpr(string outputFile){
		ofstream ofs(outputFile.c_str());
		ofs<<"//Version: PianoRoll_v170101"<<"\n";
		for(int i=0;i<comments.size();i+=1){
			ofs<<comments[i]<<endl;
		}//endfor i
		for(int n=0;n<evts.size();n+=1){
			PianoRollEvt evt=evts[n];
			ofs<<evt.ID<<"\t"<<evt.ontime<<"\t"<<evt.offtime<<"\t"<<evt.pitch<<"\t"<<evt.onvel<<"\t"<<evt.offvel<<"\t"<<evt.channel<<"\n";
		}//endfor n
		ofs.close();
	}//end WriteFileIpr

	Midi ToMidi(){
		Midi midi;
		midi.content.clear();

		MidiMessage midiMes;
		for(int i=0;i<evts.size();i+=1){
			midiMes.time=evts[i].ontime;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=144+evts[i].channel;
			midiMes.mes[1]=evts[i].pitch;
			midiMes.mes[2]=evts[i].onvel;
			midi.content.push_back(midiMes);

			midiMes.time=evts[i].offtime;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=128+evts[i].channel;
			midiMes.mes[1]=evts[i].pitch;
			midiMes.mes[2]=((evts[i].offvel>0)? evts[i].offvel:80);
			midi.content.push_back(midiMes);
		}//endfor i
		stable_sort(midi.content.begin(),midi.content.end(),LessMidiMessage());
		return midi;

	}//end ToMidi

};//end class PianoRoll

#endif // PIANOROLL_HPP

