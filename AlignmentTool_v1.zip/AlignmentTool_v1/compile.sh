#! /bin/bash

ProgramFolder="./Programs"
CodeFolder="./Code"

mkdir $ProgramFolder

g++ -O2 $CodeFolder/ErrorDetection_v170425.cpp -o $ProgramFolder/ErrorDetection
g++ -O2 $CodeFolder/RealignmentMOHMM_v170427.cpp -o $ProgramFolder/RealignmentMOHMM
g++ -O2 $CodeFolder/ScorePerfmMatcher_v170101_2.cpp -o $ProgramFolder/ScorePerfmMatcher
g++ -O2 $CodeFolder/midi2pianoroll_v161230_4.cpp -o $ProgramFolder/midi2pianoroll
g++ -O2 $CodeFolder/MusicXMLToFmt3x_v170104.cpp -o $ProgramFolder/MusicXMLToFmt3x
g++ -O2 $CodeFolder/MusicXMLToHMM_v170104.cpp -o $ProgramFolder/MusicXMLToHMM

